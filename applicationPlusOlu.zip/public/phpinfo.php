<html>
<head>
<title> PHP Test Script </title>
</head>
<body>
<p>This is PHP Version Info </p>
<?php
phpinfo( );
?>
</body>
</html> 