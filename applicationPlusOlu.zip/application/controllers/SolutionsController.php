<?php

class SolutionsController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        // action body
    }
	
    public function webApplicationsAction()
    {
        // action body
    }	
	
    public function businessAnalyticsAction()
    {
        // action body
    }		

	
    public function digitalMarketingAction()
    {
        // action body
    }	
    

}















